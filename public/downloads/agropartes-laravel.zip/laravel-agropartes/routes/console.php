<?php

// Laravel console routes
